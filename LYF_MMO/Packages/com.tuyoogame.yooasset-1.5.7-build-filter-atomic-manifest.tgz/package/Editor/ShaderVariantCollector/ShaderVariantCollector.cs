﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.IO;
using System.Threading.Tasks;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using Debug = UnityEngine.Debug;

namespace YooAsset.Editor
{
	public static class ShaderVariantCollector
	{
		private enum ESteps
		{
			None,
			Prepare,
			CollectAllMaterial,
			CollectVariants,
			CollectSleeping,
			WaitingDone,
		}

		private const float WaitMilliseconds = 1000f;
		private const float SleepMilliseconds = 100f;
		private static string _savePath;
		private static string _packageName;
		private static int _processMaxNum;
		private static Action _completedCallback;

		private static ESteps _steps = ESteps.None;
		private static Stopwatch _elapsedTime;
		private static List<string> _allMaterials;
		private static List<GameObject> _allSpheres = new List<GameObject>(1000);


		/// <summary>
		/// 开始收集
		/// </summary>
		public static void Run(string savePath, string packageName, int processMaxNum, Action completedCallback)
		{
			if (_steps != ESteps.None)
				return;

			if (Path.HasExtension(savePath) == false)
				savePath = $"{savePath}.shadervariants";
			if (Path.GetExtension(savePath) != ".shadervariants")
				throw new System.Exception("Shader variant file extension is invalid.");
			if (string.IsNullOrEmpty(packageName))
				throw new System.Exception("Package name is null or empty !");

			// 注意：先删除再保存，否则ShaderVariantCollection内容将无法及时刷新
			AssetDatabase.DeleteAsset(savePath);
			EditorTools.CreateFileDirectory(savePath);
			_savePath = savePath;
			_packageName = packageName;
			_processMaxNum = processMaxNum;
			_completedCallback = completedCallback;

			// 聚焦到游戏窗口
			EditorTools.FocusUnityGameWindow();

			// 创建临时测试场景
			CreateTempScene();

			_steps = ESteps.Prepare;
			EditorApplication.update += EditorUpdate;
		}

		private static void EditorUpdate()
		{
			if (_steps == ESteps.None)
				return;

			if (_steps == ESteps.Prepare)
			{
				ShaderVariantCollectionHelper.ClearCurrentShaderVariantCollection();
				_steps = ESteps.CollectAllMaterial;
				return; //等待一帧
			}

			if (_steps == ESteps.CollectAllMaterial)
			{
				_allMaterials = GetAllMaterials();
				_steps = ESteps.CollectVariants;
				return; //等待一帧
			}
			
			if (_steps == ESteps.CollectVariants)
			{
				int count = Mathf.Min(_processMaxNum, _allMaterials.Count);
				List<string> range = _allMaterials.GetRange(0, count);
				_allMaterials.RemoveRange(0, count);
				CollectVariants(range);

				if (_allMaterials.Count > 0)
				{
					_elapsedTime = Stopwatch.StartNew();
					_steps = ESteps.CollectSleeping;
				}
				else
				{
					_elapsedTime = Stopwatch.StartNew();
					_steps = ESteps.WaitingDone;
				}
			}

			if (_steps == ESteps.CollectSleeping)
			{
				if (_elapsedTime.ElapsedMilliseconds > SleepMilliseconds)
				{
					DestroyAllSpheres();
					_elapsedTime.Stop();
					_steps = ESteps.CollectVariants;
				}
			}

			if (_steps == ESteps.WaitingDone)
			{
				// 注意：一定要延迟保存才会起效
				if (_elapsedTime.ElapsedMilliseconds > WaitMilliseconds)
				{
					_elapsedTime.Stop();
					// 收集已结束，先解除本轮回调，清单写入失败也不会重复订阅。
					EditorApplication.update -= EditorUpdate;
					FinishCollection();
				}
			}
		}
		private static void CreateTempScene()
		{
			EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects);
		}
		private static List<string> GetAllMaterials()
		{
			int progressValue = 0;
			List<string> allAssets = new List<string>(1000);

			// 获取所有打包的资源
			CollectResult collectResult = AssetBundleCollectorSettingData.Setting.GetPackageAssets(EBuildMode.DryRunBuild, _packageName);
			foreach (var assetInfo in collectResult.CollectAssets)
			{
				string[] depends = AssetDatabase.GetDependencies(assetInfo.AssetPath, true);
				foreach (var dependAsset in depends)
				{
					if (allAssets.Contains(dependAsset) == false)
						allAssets.Add(dependAsset);
				}
				EditorTools.DisplayProgressBar("获取所有打包资源", ++progressValue, collectResult.CollectAssets.Count);
			}
			EditorTools.ClearProgressBar();

			// 搜集所有材质球
			progressValue = 0;
			List<string> allMaterial = new List<string>(1000);
			foreach (var assetPath in allAssets)
			{
				System.Type assetType = AssetDatabase.GetMainAssetTypeAtPath(assetPath);
				if (assetType == typeof(UnityEngine.Material))
				{
					allMaterial.Add(assetPath);
				}
				EditorTools.DisplayProgressBar("搜集所有材质球", ++progressValue, allAssets.Count);
			}
			EditorTools.ClearProgressBar();

			// 返回结果
			return allMaterial;
		}
		private static void CollectVariants(List<string> materials)
		{
			Camera camera = Camera.main;
			if (camera == null)
				throw new System.Exception("Not found main camera.");

			// 设置主相机
			float aspect = camera.aspect;
			int totalMaterials = materials.Count;
			float height = Mathf.Sqrt(totalMaterials / aspect) + 1;
			float width = Mathf.Sqrt(totalMaterials / aspect) * aspect + 1;
			float halfHeight = Mathf.CeilToInt(height / 2f);
			float halfWidth = Mathf.CeilToInt(width / 2f);
			camera.orthographic = true;
			camera.orthographicSize = halfHeight;
			camera.transform.position = new Vector3(0f, 0f, -10f);

			// 创建测试球体
			int xMax = (int)(width - 1);
			int x = 0, y = 0;
			int progressValue = 0;
			for (int i = 0; i < materials.Count; i++)
			{
				var material = materials[i];
				var position = new Vector3(x - halfWidth + 1f, y - halfHeight + 1f, 0f);
				var go = CreateSphere(material, position, i);
				if (go != null)
					_allSpheres.Add(go);
				if (x == xMax)
				{
					x = 0;
					y++;
				}
				else
				{
					x++;
				}
				EditorTools.DisplayProgressBar("照射所有材质球", ++progressValue, materials.Count);
			}
			EditorTools.ClearProgressBar();
		}
		private static GameObject CreateSphere(string assetPath, Vector3 position, int index)
		{
			var material = AssetDatabase.LoadAssetAtPath<Material>(assetPath);
			var shader = material.shader;
			if (shader == null)
				return null;

			var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
			go.GetComponent<Renderer>().sharedMaterial = material;
			go.transform.position = position;
			go.name = $"Sphere_{index} | {material.name}";
			return go;
		}
		private static void DestroyAllSpheres()
		{
			foreach(var go in _allSpheres)
			{
				GameObject.DestroyImmediate(go);
			}
			_allSpheres.Clear();

			// 尝试释放编辑器加载的资源
			EditorUtility.UnloadUnusedAssetsImmediate(true);
		}
		// 等待清单落盘期间维持收集状态，仅在变体和清单均保存后通知调用方。
		private static async void FinishCollection()
		{
			try
			{
				ShaderVariantCollectionHelper.SaveCurrentShaderVariantCollection(_savePath);
				await CreateManifest(_savePath);
			}
			finally
			{
				_steps = ESteps.None;
			}

			Debug.Log($"搜集SVC完毕！");
			_completedCallback?.Invoke();
		}

		/// <summary>从已保存的着色器变体集合提取 JSON 清单，并在写入完成后刷新资源。</summary>
		/// <param name="collectionPath">项目内 .shadervariants 资源路径，决定同目录清单的文件名。</param>
		private static async Task CreateManifest(string collectionPath)
		{
			AssetDatabase.Refresh(ImportAssetOptions.ForceUpdate);

			// 本次写入所依据的已保存集合，在等待文件映射释放前完成读取。
			ShaderVariantCollection svc = AssetDatabase.LoadAssetAtPath<ShaderVariantCollection>(collectionPath);
			if (svc != null)
			{
				// 提取一次集合内容，重试时仍写入同一份清单。
				var wrapper = ShaderVariantCollectionManifest.Extract(svc);
				// 沿用 YooAsset 带缩进的 JSON 格式。
				string jsonData = JsonUtility.ToJson(wrapper, true);
				// 清单与变体集同目录、同基础名，保留已有 JSON 的 .meta。
				string savePath = Path.ChangeExtension(collectionPath, ".json");
				await WriteManifestFile(savePath, jsonData);
			}

			AssetDatabase.Refresh(ImportAssetOptions.ForceUpdate);
		}

		/// <summary>先在同卷临时目录写完整 JSON，再发布到资源路径，使已有读取映射可以继续使用旧文件。</summary>
		/// <param name="savePath">最终清单的路径，仅替换 JSON 文件本身。</param>
		/// <param name="jsonData">从本轮保存的变体集合生成的完整 JSON 文本。</param>
		private static async Task WriteManifestFile(string savePath, string jsonData)
		{
			// 工程同卷的项目临时目录，不让 Unity 将中间文件作为资源导入。
			string tempDirectory = Path.GetFullPath(Path.Combine(Application.dataPath, "..", "..", "_temp", "YooAssetShaderManifests"));
			Directory.CreateDirectory(tempDirectory);
			// 每次发布独占一个文件名，失败时也只清理本次尚未移走的临时文件。
			string tempPath = Path.Combine(tempDirectory, Guid.NewGuid().ToString("N") + ".tmp");
			// 拒绝共享删除的读取句柄可能使 Windows 返回共享冲突或文件映射占用。
			const int sharingViolation = unchecked((int)0x80070020);
			// Windows ERROR_USER_MAPPED_FILE 的 HRESULT（1224）。
			const int userMappedFile = unchecked((int)0x800704C8);
			// 最多十次延迟重试，持续阻塞后保留最后一次系统异常。
			const int maxRetries = 10;
			// 每次等待的毫秒数；编辑器可在这段时间内处理导入与界面更新。
			const int retryDelayMilliseconds = 200;
			try
			{
				File.WriteAllText(tempPath, jsonData);
				// 首次发布时为零，同一份临时文件用于后续所有重试。
				for (int retry = 0; ; retry++)
				{
					try
					{
						if (File.Exists(savePath))
							File.Replace(tempPath, savePath, null);
						else
							File.Move(tempPath, savePath);
						return;
					}
					// 只等待已验证的 Windows 占用错误，其他 I/O 异常立即上抛。
					catch (IOException error) when ((error.HResult == sharingViolation || error.HResult == userMappedFile) && retry < maxRetries)
					{
						AssetDatabase.ReleaseCachedFileHandles();
						await Task.Delay(retryDelayMilliseconds);
					}
				}
			}
			finally
			{
				File.Delete(tempPath);
			}
		}
	}
}